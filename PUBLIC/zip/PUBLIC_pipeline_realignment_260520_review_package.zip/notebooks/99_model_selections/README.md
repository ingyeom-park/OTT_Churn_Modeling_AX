﻿# 99_model_selections

This folder stores model-running notebooks that should not sit in the canonical 06-18 pipeline stage folders.

## Rule
- Keep canonical pipeline stage folders for ordered pipeline work.
- Keep model-selection notebooks here, grouped by model family.
- Moving notebooks here does not mean the notebooks were executed or validated.
- Existing result folders are not moved by this notebook reorganization.

## Model folders
- catboost
- svm
- random_forest
- logistic_regression
- gradient_boosting

## Manifest
See `99_model_selections_notebook_manifest_260520.csv` for original and new notebook paths.
