﻿# 09_promotion_repurchase_2x2_EDA_260520

## stage_name
09_promotion_repurchase_2x2_EDA_260520

## stage_status
placeholder_created_pending_execution

## expected_inputs
06 canonical dataset/input checks, 07 mapping, and 08 promotion EDA outputs.

## expected_outputs
Promotion x repurchase 2x2 descriptive EDA outputs.

## why_this_stage_exists
Repurchase and non-repurchase behavior should be compared inside promotion/nonpromotion groups before modeling claims.

## what_must_not_be_done_here
Do not model. Do not claim feature importance.

## next_stage
10_feature_distribution_redundancy_pre_audit_260520
