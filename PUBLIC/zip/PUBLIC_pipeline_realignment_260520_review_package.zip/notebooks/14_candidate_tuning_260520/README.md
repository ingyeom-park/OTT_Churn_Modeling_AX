﻿# 14_candidate_tuning_260520

## stage_name
14_candidate_tuning_260520

## stage_status
placeholder_created_blocked_until_12

## expected_inputs
12 candidate comparison outputs.

## expected_outputs
Limited candidate tuning outputs after feature set, scope, and metric are locked.

## why_this_stage_exists
Tuning is only meaningful after candidate families and evaluation policy are constrained.

## what_must_not_be_done_here
Do not run Optuna until feature set, scope, and metric are locked. Do not declare final model here.

## next_stage
15_oof_score_or_sensitivity_260520
