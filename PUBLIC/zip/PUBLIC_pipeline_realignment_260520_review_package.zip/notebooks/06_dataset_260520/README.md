﻿# 06_dataset_260520

## stage_name
06_dataset_260520

## stage_status
structure_created_needs_or_has_input_audit

## expected_inputs
User-confirmed 01~05 contracts and existing PUBLIC current input candidates under PUBLIC/data, if validated later.

## expected_outputs
06_preflight_contract_inheritance_check.csv; 06_log_retention_feature_policy.csv; 06_model_input_dataset_inventory.csv; 06_dataset_schema_check.csv; 06_raw_retention_exclusion_check.csv; 06_log_retention_presence_check.csv; 06_scope_row_count_check.csv; 06_open_risks_for_07.csv; 06_safe_unsafe_wording.csv; 06_final_checks.csv; README.md.

## why_this_stage_exists
This stage inherits the 01~05 contract and prepares or verifies model-input datasets under a current feature policy.

## what_must_not_be_done_here
Do not train models. Do not create final_result.csv, trials_all.csv, oof_predictions.csv, SHAP files, segmentation files, Optuna studies, model pickles/joblib files, or model comparison summaries here.

## next_stage
07_feature_mapping_AARRR_260520

## canonical_boundary
06 is dataset/input preparation only. Modeling artifacts must not be stored under 06.

## included_substep_notebooks
- `06x_dataset_generation_260515.ipynb`: existing PUBLIC dataset generation / cold_start row-level hotfix substep.
- `06y_promo_split_260520.ipynb`: existing PUBLIC promotion split substep.

These are kept inside 06 because they are dataset/input preparation work, not model-selection notebooks.
