﻿# 08_promotion_nonpromotion_EDA_260520

## stage_name
08_promotion_nonpromotion_EDA_260520

## stage_status
placeholder_created_pending_execution

## expected_inputs
06 canonical dataset/input checks and 07 feature mapping outputs.

## expected_outputs
Promotion vs nonpromotion descriptive EDA tables and figures.

## why_this_stage_exists
Promotion and nonpromotion groups need descriptive comparison before model interpretation or business claims.

## what_must_not_be_done_here
Do not make causal claims. Do not model. Do not run SHAP. Do not segment.

## next_stage
09_promotion_repurchase_2x2_EDA_260520
