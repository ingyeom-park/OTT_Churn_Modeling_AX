﻿# 15_oof_score_or_sensitivity_260520

## stage_name
15_oof_score_or_sensitivity_260520

## stage_status
placeholder_created_blocked_until_model_candidate

## expected_inputs
A fitted candidate model and locked score orientation.

## expected_outputs
OOF score table or sensitivity audit outputs.

## why_this_stage_exists
This stage checks score behavior before interpretation and segmentation.

## what_must_not_be_done_here
Do not skip score-direction checks. Verify churn_risk = 1 - repurchase_score before downstream use.

## next_stage
16_SHAP_candidate_interpretation_260520
