# 05d v2 Feature Dictionary Report

Generated at: 2026-05-11T16:04:02

## Scope
This is a documentation-only artifact. It does not train models, run SHAP, run Optuna, create features, segmentation, or simulation.

## Column Coverage
- w1_3 modeling dataset columns: 84
- w1_4 modeling dataset columns: 89
- union columns covered in dictionary: 160

## Feature Family Counts
- genre: 78
- usage: 59
- membership: 10
- release_month: 8
- metadata: 2
- content: 2
- target: 1

## Window Counts
- w1_4: 76
- w1_3: 71
- common: 10
- metadata: 2
- target: 1

## Most Important TRUE SHAP Variables
- rank 1: w1_3_week3_watch_time (usage), mean_abs_shap=0.619701
- rank 2: w1_3_w2_minus_w1_watch_time (usage), mean_abs_shap=0.264763
- rank 3: w1_3_week1_ratio (usage), mean_abs_shap=0.227194
- rank 4: price (membership), mean_abs_shap=0.191771
- rank 5: w1_3_first_watch_rel_day (usage), mean_abs_shap=0.173888
- rank 6: w1_3_genre_ratio_thriller_crime (genre), mean_abs_shap=0.164927
- rank 7: w1_3_genre_ratio_animation_family (genre), mean_abs_shap=0.127053
- rank 8: w1_3_genre_ratio_drama (genre), mean_abs_shap=0.113679
- rank 9: w1_3_genre_session_count_drama (genre), mean_abs_shap=0.109960
- rank 10: w1_3_genre_ratio_action_adventure (genre), mean_abs_shap=0.109491

## Interpretation-Sensitive Variables
- week3/week4 watch-time variables and first/last watch relative-day variables are timing-sensitive.
- week ratio and week-to-week delta variables may be target-adjacent behavior proxies.
- genre watch_time and genre session_count variables can duplicate usage intensity rather than pure genre preference.
- is_churn_prevented has with/without variants and should not be casually interpreted.
- price and promotion-related fields can reflect policy or cohort composition.

## How Teammates Should Use This File
- Use original column names in code.
- Use suggested Korean names and presentation labels in reports or slides.
- Check `final_use_recommendation`, `leakage_risk`, and `caution` before making claims.
- Use Stage 07r TRUE SHAP sheets only as model explanation, not causal evidence.

## What Not To Claim
- Do not claim country, rating, runtime, actor, director, Wavve, or KOBIS metadata was used.
- Do not claim SHAP proves causes of churn.
- Do not use USER_KEY, membership_row_id, raw dates, or target fields as model features.
- Do not rename actual data columns based on the naming suggestion sheet.

## Outputs
- Excel workbook: `park.ingyeom/reports/tables/05d_v2_feature_dictionary/05d_v2_feature_dictionary.xlsx`
- CSV sheet copies: `park.ingyeom/reports/tables/05d_v2_feature_dictionary`
- Final checks: `park.ingyeom/reports/tables/05d_v2_feature_dictionary/05d_final_checks.csv`
