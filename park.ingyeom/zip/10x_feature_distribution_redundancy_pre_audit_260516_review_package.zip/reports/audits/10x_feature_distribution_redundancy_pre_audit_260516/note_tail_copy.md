- 본 프로젝트의 Activation은 day0~20 안에서 관측된 첫 시청이다.
- day21 이후 처음 시청한 고객은 서비스 전체 관점에서는 Activation 고객일 수 있으나, day21 scoring point 기준으로는 Activation 미관측 고객이다.
- day21 이후 첫 시청은 모델 feature가 아니라 대응기간 마케팅 액션의 결과 또는 후보로만 해석한다.

#### Referral 관련

금지 표현:

- Referral 효과를 검증했다.
- 친구 추천 쿠폰이 재구매율을 올린다.
- 20대는 반드시 공유한다.
- 본인인증 때문에 어뷰징은 불가능하다.

안전 표현:

- Referral은 현재 데이터로 직접 관측되지 않는다.
- Referral은 후속 실험 제안이다.
- 외부 자료를 통해 모바일 친화 고객군의 공유 성향을 보강할 수 있다.
- 본인인증 조건은 단순 다계정 어뷰징 위험을 제한할 수 있으나, 실제 운영에서는 중복 방지 정책이 필요하다.
- 본 프로젝트에서는 Referral 효과를 입증하지 않고, 실제 실행 시 확인해야 할 KPI를 제안한다.

#### App Store / default demographic artifact 관련

금지 표현:

- 40대 고객이 많아서 그렇다.
- 성별 N 고객은 이탈한다.
- iOS 결제 고객은 이탈한다.
- 미인증 고객은 충성도가 낮다.

안전 표현:

- `payment_is_ios`, `is_user_verified`, `age_group`, 성별 관련 변수는 실제 인구통계라기보다 결제 경로와 본인인증 정책에서 발생한 데이터 생성 구조를 반영했을 가능성이 있다.
- App Store 경유 결제와 본인인증 미수행 계정에서 default-like demographic artifact가 발생했을 수 있다.
- 이 변수들은 structural proxy risk로 관리하며, 고객 특성으로 직접 해석하지 않는다.

---

### 12. 향후 단계 반영사항

10x feature distribution / redundancy / group-proxy pre-audit에서 반드시 반영할 것:

- Activation은 day0~20 기준으로만 해석한다.
- day21 이후 첫 시청은 feature가 아니라 대응기간 activation 유도 후보로만 다룬다.
- `payment_is_ios`, `is_user_verified`, `age_group`, 성별 관련 변수는 structural proxy risk로 별도 관리한다.
- near-constant / group-proxy / default demographic artifact 가능성을 감사한다.
- 이 변수들을 제거하지 말고, 11x modeling preflight로 넘긴다.
- feature 제거 여부는 사용자 승인 전까지 결정하지 않는다.

11x / 12x 모델링에서 반드시 반영할 것:

- expanded feature set에 이 변수들이 포함되더라도 actual model input feature list를 반드시 저장하고 검수한다.
- context/profile/payment 계열이 성능을 과도하게 끌어올리는지 확인한다.
- usage/retention 계열만으로도 설명력이 유지되는지 확인한다.
- `payment_is_ios`, `is_user_verified`, `age_group`, 성별 관련 변수의 scope별 민감도를 확인한다.
- SHAP에서 이 변수들이 상위에 올라오면 고객 특성이 아니라 structural proxy caveat와 함께 해석한다.

Segmentation에서 반드시 반영할 것:

- segment 이름을 먼저 붙이지 않는다.
- 기준식과 분포 확인이 먼저다.
- `40대 미인증 iOS 고객군` 같은 이름은 금지한다.
- 필요하면 `App Store 경유 / 인증정보 결측 가능 계정군`처럼 데이터 생성 구조 중심으로 표현한다.
- final segment는 사용자 승인 전까지 provisional로 둔다.

---

### 최종 판단

현재 AARRR 프레임은 유지 가능하다.  
다만 각 단계는 반드시 본 프로젝트의 관측창과 데이터 한계를 반영해 재정의해야 한다.

가장 중요한 보정은 다음이다.

> Activation은 전체 구독기간 기준이 아니라 day0~20 관측창 기준이다.  
> 3~4주차에 처음 시청한 고객은 서비스 전체 관점에서는 activation 고객일 수 있지만, 본 프로젝트의 scoring point에서는 activation 미관측 고객이다.  
> Referral은 현재 데이터로 검증된 결과가 아니라 후속 실험 제안이다.  
> App Store 결제 / 본인인증 / default demographic artifact 가능성은 AARRR, 모델링, SHAP, segmentation 전 과정에서 caveat로 관리해야 한다.

이 원칙을 지키면 AARRR은 단순한 발표용 프레임이 아니라, 데이터 관측 가능성과 비즈니스 제언을 연결하는 안전한 구조로 사용할 수 있다.